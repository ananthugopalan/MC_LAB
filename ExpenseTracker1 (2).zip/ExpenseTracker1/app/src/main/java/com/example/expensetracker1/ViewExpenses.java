package com.example.expensetracker1;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewExpenses extends AppCompatActivity {

    ListView expensesListView;
    ArrayList<Expense> expensesList;
    DatabaseHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_expenses);

        expensesListView = findViewById(R.id.expensesListView);
        expensesList = new ArrayList<>();
        myDb = new DatabaseHelper(this);

        Cursor res = myDb.getAllData();

        if (res.getCount() == 0) {
            Toast.makeText(this, "No expenses found", Toast.LENGTH_SHORT).show();
        } else {
            while (res.moveToNext()) {
                int id = res.getInt(0);
                String date = res.getString(1);
                double amount = res.getDouble(2);
                String description = res.getString(3);
                String name = res.getString(4);
                expensesList.add(new Expense(id, date,name , amount, description));
            }

            ExpenseAdapter adapter = new ExpenseAdapter(this, R.layout.expense_item_layout, expensesList);
            expensesListView.setAdapter(adapter);
        }
    }
}
