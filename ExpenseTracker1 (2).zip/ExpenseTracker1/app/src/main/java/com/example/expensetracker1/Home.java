package com.example.expensetracker1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {
    Button btnAddExpense, btnViewExpenses, btnLogout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btnAddExpense = findViewById(R.id.btnAddExpense);
        btnViewExpenses = findViewById(R.id.btnViewExpenses);
        btnLogout = findViewById(R.id.btnLogout);

        // Set click listeners for buttons
        btnAddExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirect to AddExpense activity
                Intent intent = new Intent(Home.this, AddExpense.class);
                startActivity(intent);
            }
        });

        btnViewExpenses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirect to ViewExpenses activity
                Intent intent = new Intent(Home.this, ViewExpenses.class);
                startActivity(intent);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirect to Login activity
                Intent intent = new Intent(Home.this, Login.class);
                startActivity(intent);
                finish(); // finish the activity to prevent going back to the first page with the back button
            }
        });
    }
}
