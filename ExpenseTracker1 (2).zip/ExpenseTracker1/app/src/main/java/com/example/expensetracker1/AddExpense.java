package com.example.expensetracker1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddExpense extends AppCompatActivity {
    EditText expenseName, expenseAmount;
    Button saveButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        db = new DatabaseHelper(this);

        expenseName = (EditText) findViewById(R.id.expenseName);
        expenseAmount = (EditText) findViewById(R.id.expenseAmount);
        saveButton = (Button) findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = expenseName.getText().toString().trim();
                String amount = expenseAmount.getText().toString().trim();

                if (name.isEmpty() || amount.isEmpty()) {
                    Toast.makeText(AddExpense.this, "Please fill in all the fields", Toast.LENGTH_SHORT).show();
                } else {
                    Expense expense = new Expense(0, "", name, Double.parseDouble(amount), "");
                    boolean isInserted = db.addExpense(expense);
                    if (isInserted) {
                        Toast.makeText(AddExpense.this, "Expense saved successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AddExpense.this, "Error saving expense", Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });
    }
}