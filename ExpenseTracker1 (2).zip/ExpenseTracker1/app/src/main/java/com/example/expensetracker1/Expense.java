package com.example.expensetracker1;

public class Expense {
    private int id;
    private String date;
    private String category;
    private double amount;
    private String description;
    private  String name;
    public Expense(int id, String date, String name, double amount, String description) {
        this.id = id;
        this.date = date;
        this.name = name;
        this.amount = amount;
        this.description = description;
    }
    public Expense(int id, String description, double amount, String date) {
        this.description = description;
        this.amount = amount;
        this.date = date;
    }


    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setAmount(double amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount must be >= 0");
        }
        this.amount = amount;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }
}