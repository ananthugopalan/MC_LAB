package com.example.expensetracker1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ExpenseAdapter extends ArrayAdapter<Expense> {

    private Context context;
    private int resource;
    private ArrayList<Expense> expenses;

    public ExpenseAdapter(Context context, int resource, ArrayList<Expense> expenses) {
        super(context, resource, expenses);
        this.context = context;
        this.resource = resource;
        this.expenses = expenses;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(resource, null);
        }

        Expense expense = expenses.get(position);

        TextView dateTextView = view.findViewById(R.id.dateTextView);
        TextView categoryTextView = view.findViewById(R.id.categoryTextView);
        TextView amountTextView = view.findViewById(R.id.amountTextView);

        dateTextView.setText(expense.getDate());
        categoryTextView.setText(expense.getName());
        amountTextView.setText(String.format("%.2f", expense.getAmount()));


        return view;
    }
}
