package com.example.expensetracker1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "home.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "users";
    private static final String TABLE_EXPENSES = "Expenses";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "USERNAME";
    public static final String COL_3 = "PASSWORD";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";
    private static final String EXPENSE_COLUMN_ID = "id";
    private static final String EXPENSE_COLUMN_DESCRIPTION = "description";
    private static final String EXPENSE_COLUMN_AMOUNT = "amount";
    private static final String EXPENSE_COLUMN_DATE = "date";
    private static  final String EXPENSE_COLUMN_NAME = "name";
    private SQLiteDatabase db;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "USERNAME TEXT, PASSWORD TEXT)");
        String CREATE_EXPENSES_TABLE = "CREATE TABLE " + TABLE_EXPENSES + " (" +
                EXPENSE_COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                EXPENSE_COLUMN_DESCRIPTION + " TEXT, " +
                EXPENSE_COLUMN_AMOUNT + " REAL, " +
                EXPENSE_COLUMN_DATE + " TEXT, "+ EXPENSE_COLUMN_NAME + " TEXT )";
        db.execSQL(CREATE_EXPENSES_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXPENSES);
        onCreate(db);
    }
        // Add a new expense to the database
        public boolean addExpense(Expense expense) {
            db = this.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(EXPENSE_COLUMN_NAME,expense.getName());
            values.put(EXPENSE_COLUMN_DESCRIPTION, expense.getDescription());
            values.put(EXPENSE_COLUMN_AMOUNT, expense.getAmount());
            values.put(EXPENSE_COLUMN_DATE, expense.getDate());

            db.insert(TABLE_EXPENSES, null, values);
            db.close();
            return false;
        }

        // Get a list of all expenses in the database
        public List<Expense> getAllExpenses() {
            List<Expense> expensesList = new ArrayList<>();
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EXPENSES, null);
            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(EXPENSE_COLUMN_ID));
                    @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex(EXPENSE_COLUMN_DESCRIPTION));
                    @SuppressLint("Range") double amount = cursor.getDouble(cursor.getColumnIndex(EXPENSE_COLUMN_AMOUNT));
                    @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(EXPENSE_COLUMN_DATE));
                    expensesList.add(new Expense(id, description, amount, date));
                } while (cursor.moveToNext());
            }
            cursor.close();
            db.close();
            return expensesList;
        }


        // Get a list of expenses for a given date range
        public List<Expense> getExpensesForDateRange(String startDate, String endDate) {
            List<Expense> expensesList = new ArrayList<>();

            db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EXPENSES + " WHERE " + EXPENSE_COLUMN_DATE + " BETWEEN ? AND ?", new String[]{startDate, endDate});

            if (cursor.moveToFirst()) {
                do {
                    @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(EXPENSE_COLUMN_ID));
                    @SuppressLint("Range") String description = cursor.getString(cursor.getColumnIndex(EXPENSE_COLUMN_DESCRIPTION));
                    @SuppressLint("Range") double amount = cursor.getDouble(cursor.getColumnIndex(EXPENSE_COLUMN_AMOUNT));
                    @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(EXPENSE_COLUMN_DATE));
                    expensesList.add(new Expense(id, description, amount, date));
                } while (cursor.moveToNext());
            }

            cursor.close();
            db.close();
            return expensesList;
        }

        public Cursor getAllData() {
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor res = db.rawQuery("SELECT * FROM " + TABLE_EXPENSES, null);
            return res;
        }

    }